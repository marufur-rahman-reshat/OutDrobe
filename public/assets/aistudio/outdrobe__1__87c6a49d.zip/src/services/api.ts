import type {
  CalendarPlan,
  ClothingItem,
  Outfit,
  OutfitSuggestion,
  UserProfile,
  WearLogEntry,
} from '../types/outdrobe';

const TOKEN_STORAGE_KEY = 'outdrobe_session_token';

export interface WorkspaceSnapshot {
  wardrobe: ClothingItem[];
  outfits: Outfit[];
  calendar: CalendarPlan[];
  wearLogs: WearLogEntry[];
}

export function getSavedToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_STORAGE_KEY);
  } catch {
    return null;
  }
}

export function setSavedToken(token: string | null): void {
  try {
    if (token) {
      localStorage.setItem(TOKEN_STORAGE_KEY, token);
    } else {
      localStorage.removeItem(TOKEN_STORAGE_KEY);
    }
  } catch {
    // Ignore storage quota errors in restricted frames
  }
}

async function requestJson<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getSavedToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...((options.headers as Record<string, string>) || {}),
  };
  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  const res = await fetch(path, {
    ...options,
    headers,
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `Request failed with status ${res.status}`);
  }
  return data as T;
}

export const outdrobeApi = {
  async loginDemo(): Promise<{ token: string; user: UserProfile }> {
    const res = await requestJson<{ token: string; user: UserProfile }>('/api/auth/demo', {
      method: 'POST',
    });
    setSavedToken(res.token);
    return res;
  },

  async login(email: string, password: string): Promise<{ token: string; user: UserProfile }> {
    const res = await requestJson<{ token: string; user: UserProfile }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    setSavedToken(res.token);
    return res;
  },

  async register(
    displayName: string,
    email: string,
    password: string,
    startWithSampleCapsule: boolean
  ): Promise<{ token: string; user: UserProfile }> {
    const res = await requestJson<{ token: string; user: UserProfile }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({ displayName, email, password, startWithSampleCapsule }),
    });
    setSavedToken(res.token);
    return res;
  },

  async getCurrentUser(): Promise<{ user: UserProfile }> {
    return requestJson<{ user: UserProfile }>('/api/auth/me');
  },

  async logout(): Promise<void> {
    try {
      await requestJson('/api/auth/logout', { method: 'POST' });
    } finally {
      setSavedToken(null);
    }
  },

  async getWorkspace(): Promise<WorkspaceSnapshot> {
    return requestJson<WorkspaceSnapshot>('/api/workspace');
  },

  async createGarment(payload: Partial<ClothingItem>): Promise<{ item: ClothingItem }> {
    return requestJson<{ item: ClothingItem }>('/api/wardrobe', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  async updateGarment(id: string, payload: Partial<ClothingItem>): Promise<{ item: ClothingItem }> {
    return requestJson<{ item: ClothingItem }>(`/api/wardrobe/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
  },

  async deleteGarment(id: string): Promise<void> {
    await requestJson(`/api/wardrobe/${id}`, { method: 'DELETE' });
  },

  async createOutfit(payload: Partial<Outfit>): Promise<{ outfit: Outfit }> {
    return requestJson<{ outfit: Outfit }>('/api/outfits', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  async updateOutfit(id: string, payload: Partial<Outfit>): Promise<{ outfit: Outfit }> {
    return requestJson<{ outfit: Outfit }>(`/api/outfits/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
  },

  async deleteOutfit(id: string): Promise<void> {
    await requestJson(`/api/outfits/${id}`, { method: 'DELETE' });
  },

  async scheduleOutfit(payload: {
    date: string;
    outfitId: string;
    occasionNote: string;
  }): Promise<{ plan: CalendarPlan }> {
    return requestJson<{ plan: CalendarPlan }>('/api/calendar', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  async removeCalendarPlan(id: string): Promise<void> {
    await requestJson(`/api/calendar/${id}`, { method: 'DELETE' });
  },

  async logWear(payload: {
    date: string;
    outfitId: string | null;
    itemIds?: string[];
    occasion: string;
    weatherNote: string;
    notes: string;
    calendarPlanId?: string;
  }): Promise<{
    entry: WearLogEntry;
    wardrobe: ClothingItem[];
    outfits: Outfit[];
    calendar: CalendarPlan[];
  }> {
    return requestJson('/api/wear-logs', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  async getSuggestions(occasion: string, climate: string): Promise<{ suggestions: OutfitSuggestion[] }> {
    const params = new URLSearchParams({ occasion, climate });
    return requestJson<{ suggestions: OutfitSuggestion[] }>(`/api/suggestions?${params.toString()}`);
  },
};
